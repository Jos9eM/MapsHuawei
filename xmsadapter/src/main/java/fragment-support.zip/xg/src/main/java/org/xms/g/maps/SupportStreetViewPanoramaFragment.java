package org.xms.g.maps;

public class SupportStreetViewPanoramaFragment extends com.google.android.gms.maps.SupportStreetViewPanoramaFragment {
    public static org.xms.g.maps.SupportStreetViewPanoramaFragment newInstance() {
        return new org.xms.g.maps.SupportStreetViewPanoramaFragment();
    }

    public static org.xms.g.maps.SupportStreetViewPanoramaFragment newInstance(org.xms.g.maps.StreetViewPanoramaOptions streetViewPanoramaOptions) {
        android.os.Bundle bundle = new android.os.Bundle();
        bundle.putParcelable("StreetViewPanoramaOptions", (com.google.android.gms.maps.StreetViewPanoramaOptions)(streetViewPanoramaOptions.getGInstance()));
        org.xms.g.maps.SupportStreetViewPanoramaFragment supportStreetViewPanoramaFragment = new org.xms.g.maps.SupportStreetViewPanoramaFragment();
        supportStreetViewPanoramaFragment.setArguments(bundle);
        return supportStreetViewPanoramaFragment;
    }

    public SupportStreetViewPanoramaFragment() {
    }

    public void getStreetViewPanoramaAsync(org.xms.g.maps.OnStreetViewPanoramaReadyCallback onStreetViewPanoramaReadyCallback) {
        super.getStreetViewPanoramaAsync(onStreetViewPanoramaReadyCallback.getGInstanceOnStreetViewPanoramaReadyCallback());
    }
}