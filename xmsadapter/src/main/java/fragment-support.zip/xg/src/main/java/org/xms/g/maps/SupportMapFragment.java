package org.xms.g.maps;

public class SupportMapFragment extends com.google.android.gms.maps.SupportMapFragment {
    public static org.xms.g.maps.SupportMapFragment newInstance() {
        return new org.xms.g.maps.SupportMapFragment();
    }

    public static org.xms.g.maps.SupportMapFragment newInstance(org.xms.g.maps.ExtensionMapOptions extensionMapOptions) {
        android.os.Bundle bundle = new android.os.Bundle();
        bundle.putParcelable("MapOptions", (com.google.android.gms.maps.GoogleMapOptions)(extensionMapOptions.getGInstance()));
        org.xms.g.maps.SupportMapFragment supportMapFragment = new org.xms.g.maps.SupportMapFragment();
        supportMapFragment.setArguments(bundle);
        return supportMapFragment;
    }

    public SupportMapFragment() {
    }

    public void getMapAsync(org.xms.g.maps.OnMapReadyCallback onMapReadyCallback) {
        super.getMapAsync(onMapReadyCallback.getGInstanceOnMapReadyCallback());
    }
}