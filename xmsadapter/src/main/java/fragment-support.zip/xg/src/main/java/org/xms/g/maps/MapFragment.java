package org.xms.g.maps;

public class MapFragment extends com.google.android.gms.maps.MapFragment {
    public static org.xms.g.maps.MapFragment newInstance() {
        return new org.xms.g.maps.MapFragment();
    }

    public static org.xms.g.maps.MapFragment newInstance(org.xms.g.maps.ExtensionMapOptions extensionMapOptions) {
        android.os.Bundle bundle = new android.os.Bundle();
        bundle.putParcelable("MapOptions", (com.google.android.gms.maps.GoogleMapOptions)(extensionMapOptions.getGInstance()));
        org.xms.g.maps.MapFragment mapFragment = new org.xms.g.maps.MapFragment();
        mapFragment.setArguments(bundle);
        return mapFragment;
    }

    public MapFragment() {
    }

    public void getMapAsync(org.xms.g.maps.OnMapReadyCallback onMapReadyCallback) {
        super.getMapAsync(onMapReadyCallback.getGInstanceOnMapReadyCallback());
    }
}