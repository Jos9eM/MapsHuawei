package org.xms.g.maps;

public class StreetViewPanoramaFragment extends com.google.android.gms.maps.StreetViewPanoramaFragment {
    public static org.xms.g.maps.StreetViewPanoramaFragment newInstance() {
        return new org.xms.g.maps.StreetViewPanoramaFragment();
    }

    public static org.xms.g.maps.StreetViewPanoramaFragment newInstance(org.xms.g.maps.StreetViewPanoramaOptions streetViewPanoramaOptions) {
        android.os.Bundle bundle = new android.os.Bundle();
        bundle.putParcelable("StreetViewPanoramaOptions", (com.google.android.gms.maps.StreetViewPanoramaOptions)(streetViewPanoramaOptions.getGInstance()));
        org.xms.g.maps.StreetViewPanoramaFragment streetViewPanoramaFragment = new org.xms.g.maps.StreetViewPanoramaFragment();
        streetViewPanoramaFragment.setArguments(bundle);
        return streetViewPanoramaFragment;
    }

    public StreetViewPanoramaFragment() {
    }

    public void getStreetViewPanoramaAsync(org.xms.g.maps.OnStreetViewPanoramaReadyCallback onStreetViewPanoramaReadyCallback) {
        super.getStreetViewPanoramaAsync(onStreetViewPanoramaReadyCallback.getGInstanceOnStreetViewPanoramaReadyCallback());
    }
}