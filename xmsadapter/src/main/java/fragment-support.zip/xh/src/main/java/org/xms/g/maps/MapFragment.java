package org.xms.g.maps;

public class MapFragment extends com.huawei.hms.maps.MapFragment {
    public static org.xms.g.maps.MapFragment newInstance() {
        return new org.xms.g.maps.MapFragment();
    }

    public static org.xms.g.maps.MapFragment newInstance(org.xms.g.maps.ExtensionMapOptions extensionMapOptions) {
        org.xms.g.maps.MapFragment mapFragment = new org.xms.g.maps.MapFragment();
        android.os.Bundle bundle = new android.os.Bundle();
        bundle.putParcelable("HuaweiMapOptions", (com.huawei.hms.maps.HuaweiMapOptions)(extensionMapOptions.getGInstance()));
        mapFragment.setArguments(bundle);
        return mapFragment;
    }

    public MapFragment() {
    }

    public void getMapAsync(org.xms.g.maps.OnMapReadyCallback onMapReadyCallback) {
        super.getMapAsync(onMapReadyCallback.getHInstanceOnMapReadyCallback());
    }
}