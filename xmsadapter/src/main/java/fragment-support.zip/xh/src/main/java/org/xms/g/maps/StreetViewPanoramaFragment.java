package org.xms.g.maps;

public class StreetViewPanoramaFragment extends com.huawei.hms.maps.StreetViewPanoramaFragment {
    public static org.xms.g.maps.StreetViewPanoramaFragment newInstance() {
        return new org.xms.g.maps.StreetViewPanoramaFragment();
    }

    public static org.xms.g.maps.StreetViewPanoramaFragment newInstance(org.xms.g.maps.StreetViewPanoramaOptions streetViewPanoramaOptions) {
        android.os.Bundle bundle = new android.os.Bundle();
        bundle.putParcelable("StreetOptions", (com.huawei.hms.maps.StreetViewPanoramaOptions)(streetViewPanoramaOptions.getHInstance()));
        org.xms.g.maps.StreetViewPanoramaFragment streetViewPanoramaFragment = new org.xms.g.maps.StreetViewPanoramaFragment();
        streetViewPanoramaFragment.setArguments(bundle);
        return streetViewPanoramaFragment;
    }

    public StreetViewPanoramaFragment() {
    }

    public void getStreetViewPanoramaAsync(org.xms.g.maps.OnStreetViewPanoramaReadyCallback onStreetViewPanoramaReadyCallback) {
        super.getStreetViewPanoramaAsync(onStreetViewPanoramaReadyCallback.getHInstanceOnStreetViewPanoramaReadyCallback());
    }
}