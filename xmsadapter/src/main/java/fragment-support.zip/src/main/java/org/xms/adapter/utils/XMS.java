package org.xms.adapter.utils;

import android.app.Application;
import android.content.Context;
import org.xms.BuildConfig;
import org.xms.g.utils.GlobalEnvSetting;

import java.io.File;
import java.util.Arrays;
import java.util.List;

public class XMS {
    private XClassLoader gLoader;

    private XClassLoader hLoader;

    private Boolean initialized = false;

    private static final XMS instance = new XMS();

    public static void init(Application app) {
        synchronized (instance) {
            if (instance.initialized) {
                throw new IllegalStateException("XMS has already been initialized");
            }
            instance.initialized = true;
            // TODO: read the implementation list from directory
            List<String> sources = Arrays.asList("xg", "xh");
            for (String src : sources) {
                String assetPath = String.format("%s/%s.dex", BuildConfig.XMS_ASSET_PATH, src);
                String cacheName = src + ".dex";
                FileUtils.copyAsset(app, assetPath, cacheName);
            }
            if (!hookClassloader(app)) {
                throw new IllegalStateException("Failed to hook class loader");
            }
            resolveRoutingStrategy(app);
        }
    }

    private static boolean hookClassloader(Application app) {
        Context base = app.getBaseContext();
        Object packageInfo = ReflectionUtils.readField(base, "mPackageInfo");
        if (packageInfo == null) {
            return false;
        }
        ClassLoader loader = ReflectionUtils.readField(ClassLoader.class, packageInfo, "mClassLoader");
        if (loader == null) {
            return false;
        }
        ClassLoader baseLoader = ReflectionUtils.readField(ClassLoader.class, loader, "parent");
        instance.gLoader = new XClassLoader(FileUtils.getCacheDir(app).getAbsolutePath() + File.separator + "xg.dex",
                FileUtils.getCacheDir(app).getAbsolutePath(), null, baseLoader, loader);
        instance.hLoader = new XClassLoader(FileUtils.getCacheDir(app).getAbsolutePath() + File.separator + "xh.dex",
                FileUtils.getCacheDir(app).getAbsolutePath(), null, instance.gLoader, loader);
        ReflectionUtils.writeField(loader, "parent", instance.hLoader);
        return true;
    }

    private static void resolveRoutingStrategy(Context context) {
        if (GlobalEnvSetting.isHms()) {
            instance.hLoader.enable();
            instance.gLoader.disable();
        } else {
            instance.gLoader.enable();
            instance.hLoader.disable();
        }
    }
}
