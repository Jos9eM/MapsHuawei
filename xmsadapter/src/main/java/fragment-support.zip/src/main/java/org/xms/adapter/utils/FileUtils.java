package org.xms.adapter.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

public class FileUtils {
    private static final String TAG = "FileUtils";

    public static final int BUFFER_SIZE = 1024;

    private static void copyFile(Context context, String src, File dest) {
        Log.i(TAG, "copy from " + src + " to " + dest.getAbsolutePath());
        try (InputStream ins = context.getAssets().open(src);
             OutputStream os = new FileOutputStream(dest)) {
            byte[] bytes = new byte[BUFFER_SIZE];
            int total = 0;
            int i;
            while ((i = ins.read(bytes)) != -1) {
                total += i;
                os.write(bytes, 0, i);
            }
            Log.i(TAG, "" + total + " bytes written");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static boolean copyAsset(Context context, String assetPath, String targetName) {
        File cacheFile = FileUtils.getCacheDir(context);
        String internalPath = cacheFile.getAbsolutePath() + File.separator + targetName;
        File destFile = new File(internalPath);
        try {
            if (!destFile.exists()) {
                destFile.createNewFile();
            }
            FileUtils.copyFile(context, assetPath, destFile);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean hasExternalStorage() {
        return Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED);
    }

    public static File getCacheDir(Context context) {
        File cache;
        if (hasExternalStorage()) {
            cache = context.getExternalCacheDir();
        } else {
            cache = context.getCacheDir();
        }
        if (!cache.exists()) {
            cache.mkdirs();
        }
        return cache;
    }
}
